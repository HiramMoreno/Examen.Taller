import { Controller, Get, Render } from '@nestjs/common';



@Controller('examen')
export class ExamenController {     
    @Get()
    @Render('examen')
    ruta(){    }
}
