import { Module } from '@nestjs/common';
import { ExamenController } from './examen.controller';

@Module({
  controllers: [ExamenController]
})
export class ExamenModule {}
